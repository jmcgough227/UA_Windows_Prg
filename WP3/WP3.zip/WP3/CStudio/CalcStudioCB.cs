using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Reflection;
using System.Web.UI.HtmlControls;

namespace WP
{
    // This class stores much of the loaded DLL's info for later use
    public class DLLInfo
    {
        public Type classType;
        public string nsName;
        public string className;
        public MethodInfo[] methods;

        // Constructor
        // Not entirely sure why I had to make it public to work
        // Methods default to private maybe?
        public DLLInfo(Type ct)
        {
            this.classType = ct;
            this.nsName = ct.Namespace;
            this.className = ct.Name;
            this.methods = ct.GetMethods();
        }

        // End of DLLInfo class
    }

    /********************************************************************************/

    public class CalcStudioCB : Page
    {
        // Create objects to store information on DLL
        Assembly asm;
        Type[] calcTypes;
        DLLInfo[] dllClassList;
        string dllName = "C:\\inetpub\\wwwroot\\WP_s2015\\jrm43\\CStudio\\bin\\calc.dll";

        protected Table FormatTable;
        protected Table ClassTable;
        protected Table MethodTable;

        protected HtmlGenericControl SimpleCalcSpace;
        protected HtmlGenericControl ComplexCalcSpace;

        protected Label SimpleLabel;
        protected Label ComplexLabel;
        protected CheckBox SimpleRadio;
        protected CheckBox ComplexRadio;

        protected Label MethodLabel1;
        protected Label MethodLabel2;
        protected Label MethodLabel3;
        protected Label MethodLabel4;
        protected Label MethodLabel5;
        protected Label MethodLabel6;
        protected Label MethodLabel7;
        protected Label MethodLabel8;

        protected CheckBox MethodBox1;
        protected CheckBox MethodBox2;
        protected CheckBox MethodBox3;
        protected CheckBox MethodBox4;
        protected CheckBox MethodBox5;
        protected CheckBox MethodBox6;
        protected CheckBox MethodBox7;
        protected CheckBox MethodBox8;

        protected TableRow MethodHeader;

        protected TableRow MethodRow1;
        protected TableRow MethodRow2;
        protected TableRow MethodRow3;
        protected TableRow MethodRow4;
        protected TableRow MethodRow5;
        protected TableRow MethodRow6;
        protected TableRow MethodRow7;
        protected TableRow MethodRow8;

        protected Label ParamLabel1;
        protected Label ParamLabel2;
        protected Label ParamLabel3;
        protected Label ParamLabel4;
        protected Label ParamLabel5;
        protected Label ParamLabel6;
        protected Label ParamLabel7;
        protected Label ParamLabel8;

        protected TableRow ButtonRow;

        protected TextBox SimpleOp1;
        protected TextBox SimpleOp2;
        protected Button SimpleAddButton;
        protected Button SimpleSubButton;
        protected Button SimpleMulButton;
        protected Button SimpleDivButton;
        protected TextBox SimpleResult;

        protected TextBox ComplexReal1;
        protected TextBox ComplexImag1;
        protected TextBox ComplexReal2;
        protected TextBox ComplexImag2;
        protected Button ComplexAddButton;
        protected Button ComplexSubButton;
        protected Button ComplexMulButton;
        protected Button ComplexDivButton;
        protected TextBox ComplexResult;

        protected void Assembly_Info()
        {
            asm = Assembly.LoadFrom(dllName);

            // Store various class 1information in an array
            calcTypes = asm.GetTypes();
            dllClassList = new DLLInfo[calcTypes.Length];

            int pos = 0;

            // Populate dllInfo array
            foreach (Type calcType in calcTypes)
            {
                dllClassList[pos] = new DLLInfo(calcType);
                ++pos;
            }
        }

        public void Page_Init(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

                Assembly_Info();
                //-------------------- Reflection completed --------------------//

                // Get info from each class in DLL and fill out their labels
                foreach (DLLInfo calc in dllClassList)
                {
                    if (calc.className == "Simple") SimpleLabel.Text = calc.className;
                    if (calc.className == "Complex") ComplexLabel.Text = calc.className;

                    // Get info from each method in class and fill out their labels
                    foreach (MethodInfo method in calc.methods)
                    {
                        string text = "";

                        // Get info from each parameter in method and fill out their labels
                        foreach (ParameterInfo par in method.GetParameters())
                        {
                            text += par.ParameterType + " " + par.Name + ", ";
                        }

                        if (calc.className == "Simple")
                        {
                            if (method.Name == "add")
                            {
                                MethodLabel1.Text = method.Name;
                                ParamLabel1.Text = text;
                            }
                            else if (method.Name == "sub")
                            {
                                MethodLabel2.Text = method.Name;
                                ParamLabel2.Text = text;
                            }
                            else if (method.Name == "mult")
                            {
                                MethodLabel3.Text = method.Name;
                                ParamLabel3.Text = text;
                            }
                            else if (method.Name == "div")
                            {
                                MethodLabel4.Text = method.Name;
                                ParamLabel4.Text = text;
                            }
                        }
                        else if (calc.className == "Complex")
                        {
                            if (method.Name == "add")
                            {
                                MethodLabel5.Text = method.Name;
                                ParamLabel5.Text = text;
                            }
                            else if (method.Name == "sub")
                            {
                                MethodLabel6.Text = method.Name;
                                ParamLabel6.Text = text;
                            }
                            else if (method.Name == "mult")
                            {
                                MethodLabel7.Text = method.Name;
                                ParamLabel7.Text = text;
                            }
                            else if (method.Name == "div")
                            {
                                MethodLabel8.Text = method.Name;
                                ParamLabel8.Text = text;
                            }
                        }
                    }
                }
            }
        }


        protected void classSelect(object sender, EventArgs e)
        {
            MethodTable.Visible = true;
            MethodHeader.Visible = true;
            ButtonRow.Visible = true;

            if (SimpleRadio.Checked)
            {
                MethodRow1.Visible = true;
                MethodRow2.Visible = true;
                MethodRow3.Visible = true;
                MethodRow4.Visible = true;
            }
            else
            {
                MethodRow1.Visible = false;
                MethodRow2.Visible = false;
                MethodRow3.Visible = false;
                MethodRow4.Visible = false;
            }

            if (ComplexRadio.Checked)
            {
                MethodRow5.Visible = true;
                MethodRow6.Visible = true;
                MethodRow7.Visible = true;
                MethodRow8.Visible = true;
            }
            else
            {
                MethodRow5.Visible = false;
                MethodRow6.Visible = false;
                MethodRow7.Visible = false;
                MethodRow8.Visible = false;
            }
        }

        protected void OnCreate(object sender, EventArgs e)
        {
            if (MethodBox1.Checked || MethodBox2.Checked || MethodBox3.Checked || MethodBox4.Checked)
            {
                SimpleCalcSpace.Visible = true;
            }

            if (MethodBox5.Checked || MethodBox6.Checked || MethodBox7.Checked || MethodBox8.Checked)
            {
                ComplexCalcSpace.Visible = true;
            }

            SimpleAddButton.Visible = MethodBox1.Checked;
            SimpleSubButton.Visible = MethodBox2.Checked;
            SimpleMulButton.Visible = MethodBox3.Checked;
            SimpleDivButton.Visible = MethodBox4.Checked;

            ComplexAddButton.Visible = MethodBox5.Checked;
            ComplexSubButton.Visible = MethodBox6.Checked;
            ComplexMulButton.Visible = MethodBox7.Checked;
            ComplexDivButton.Visible = MethodBox8.Checked;
        }


        protected void OnSimpleAdd(object sender, EventArgs e)
        {
            Assembly_Info();

            Object simple = Activator.CreateInstance(dllClassList[0].classType, new object[] { });
            object[] simpleParameters = new object[2];

            simpleParameters[0] = Convert.ToInt32(SimpleOp1.Text);

            simpleParameters[1] = Convert.ToInt32(SimpleOp2.Text);

            SimpleResult.Text = (string)dllClassList[0].methods[0].Invoke(simple, simpleParameters);
        }

        protected void OnSimpleSub(object sender, EventArgs e)
        {
            Assembly_Info();

            Object simple = Activator.CreateInstance(dllClassList[0].classType, new object[] { });
            object[] simpleParameters = new object[2];

            simpleParameters[0] = Convert.ToInt32(SimpleOp1.Text);

            simpleParameters[1] = Convert.ToInt32(SimpleOp2.Text);

            SimpleResult.Text = (string)dllClassList[0].methods[1].Invoke(simple, simpleParameters);
        }

        protected void OnSimpleMul(object sender, EventArgs e)
        {
            Assembly_Info();

            Object simple = Activator.CreateInstance(dllClassList[0].classType, new object[] { });
            object[] simpleParameters = new object[2];

            simpleParameters[0] = Convert.ToInt32(SimpleOp1.Text);

            simpleParameters[1] = Convert.ToInt32(SimpleOp2.Text);

            SimpleResult.Text = (string)dllClassList[0].methods[2].Invoke(simple, simpleParameters);
        }

        protected void OnSimpleDiv(object sender, EventArgs e)
        {
            Assembly_Info();

            Object simple = Activator.CreateInstance(dllClassList[0].classType, new object[] { });
            object[] simpleParameters = new object[2];

            simpleParameters[0] = Convert.ToInt32(SimpleOp1.Text);

            simpleParameters[1] = Convert.ToInt32(SimpleOp2.Text);

            SimpleResult.Text = (string)dllClassList[0].methods[3].Invoke(simple, simpleParameters);
        }

        protected void OnComplexAdd(object sender, EventArgs e)
        {
            Assembly_Info();

            Object complex = Activator.CreateInstance(dllClassList[1].classType, new object[] { });
            object[] complexParameters = new object[4];

            complexParameters[0] = Convert.ToInt32(ComplexReal1.Text);
            complexParameters[1] = Convert.ToInt32(ComplexImag1.Text);

            complexParameters[2] = Convert.ToInt32(ComplexReal2.Text);
            complexParameters[3] = Convert.ToInt32(ComplexImag2.Text);

            ComplexResult.Text = (string)dllClassList[1].methods[0].Invoke(complex, complexParameters);
        }

        protected void OnComplexSub(object sender, EventArgs e)
        {
            Assembly_Info();

            Object complex = Activator.CreateInstance(dllClassList[1].classType, new object[] { });
            object[] complexParameters = new object[4];

            complexParameters[0] = Convert.ToInt32(ComplexReal1.Text);
            complexParameters[1] = Convert.ToInt32(ComplexImag1.Text);

            complexParameters[2] = Convert.ToInt32(ComplexReal2.Text);
            complexParameters[3] = Convert.ToInt32(ComplexImag2.Text);

            ComplexResult.Text = (string)dllClassList[1].methods[1].Invoke(complex, complexParameters);
        }

        protected void OnComplexMul(object sender, EventArgs e)
        {
            Assembly_Info();

            Object complex = Activator.CreateInstance(dllClassList[1].classType, new object[] { });
            object[] complexParameters = new object[4];

            complexParameters[0] = Convert.ToInt32(ComplexReal1.Text);
            complexParameters[1] = Convert.ToInt32(ComplexImag1.Text);

            complexParameters[2] = Convert.ToInt32(ComplexReal2.Text);
            complexParameters[3] = Convert.ToInt32(ComplexImag2.Text);

            ComplexResult.Text = (string)dllClassList[1].methods[2].Invoke(complex, complexParameters);
        }

        protected void OnComplexDiv(object sender, EventArgs e)
        {
            Assembly_Info();

            Object complex = Activator.CreateInstance(dllClassList[1].classType, new object[] { });
            object[] complexParameters = new object[4];

            complexParameters[0] = Convert.ToInt32(ComplexReal1.Text);
            complexParameters[1] = Convert.ToInt32(ComplexImag1.Text);

            complexParameters[2] = Convert.ToInt32(ComplexReal2.Text);
            complexParameters[3] = Convert.ToInt32(ComplexImag2.Text);

            ComplexResult.Text = (string)dllClassList[1].methods[3].Invoke(complex, complexParameters);
        }
    }
}
