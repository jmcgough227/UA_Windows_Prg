using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public class LanderPage : Page
{
    const double gravity = 1.625;      // Lunar gravity
    const double landermass = 17198.0; // Lander mass

    protected Label Altitude;
    protected Label Velocity;
    protected Label Acceleration;
    protected Label Fuel;
    protected Label ElapsedTime;
    protected Label Output;
    protected TextBox Throttle;
    protected TextBox Seconds;

    public void OnCalculate (Object sender, EventArgs e)
    {
        double alt1 = Convert.ToDouble (Altitude.Text);

        if (alt1 > 0.0)  {
            // Check for blank input fields
            if (Throttle.Text.Length == 0) {
                Output.Text = "Error: Required field missing";
                return;
            }

            if (Seconds.Text.Length == 0) {
                Output.Text = "Error: Required field missing";
                return;
            }

            // Extract and validate user input
            double throttle;
            double sec;

            try {
                throttle = Convert.ToDouble (Throttle.Text);
                sec = Convert.ToDouble (Seconds.Text);
            }
            catch (FormatException) {
                Output.Text = "Error: Invalid input";
                return;
            }

            if (throttle < 0.0 || throttle > 100.0) {
                Output.Text = "Error: Invalid throttle value";
                return;
            }

            if (sec <= 0.0) {
                Output.Text = "Error: Invalid burn time";
                return;
            }

            // Extract flight parameters from the Label controls
            double vel1 = Convert.ToDouble (Velocity.Text);
            double fuel1 = Convert.ToDouble (Fuel.Text);
            double time1 = Convert.ToDouble (ElapsedTime.Text);

            // Compute thrust and remaining fuel
            double thrust = throttle * 1200.0;
            double fuel = (thrust * sec) / 2600.0;
            double fuel2 = fuel1 - fuel;

            // Make sure there's enough fuel
            if (fuel2 < 0.0) {
                Output.Text = "Error: Insufficient fuel";
                return;
            }
				
            // Compute new flight parameters
            Output.Text = "";
            double avgmass = landermass + ((fuel1 + fuel2) / 2.0);
            double force = thrust - (avgmass * gravity);
            double acc = force / avgmass;

            double vel2 = vel1 + (acc * sec);
            double avgvel = (vel1 + vel2) / 2.0;
            double alt2 = alt1 + (avgvel * sec);
            double time2 = time1 + sec;

            // If altitude <= 0, then we've landed
            if (alt2 <= 0.0) {
                double mul = alt1 / (alt1 - alt2);
                vel2 = vel1 - ((vel1 - vel2) * mul);
                alt2 = 0.0;
                fuel2 = fuel1 - ((fuel1 - fuel2) * mul);
                time2 = time1 - ((time1 - time2) * mul);

                if (vel2 >= -4.0)
                    Output.Text = "The Eagle has landed";
                else
                    Output.Text = "Kaboom!";
            }			

            // Update the Labels to show latest flight parameters
            Altitude.Text = alt2.ToString ("f1");
            Velocity.Text = vel2.ToString ("f1");
            Acceleration.Text = acc.ToString ("f1");
            Fuel.Text = fuel2.ToString ("f1");
            ElapsedTime.Text = time2.ToString ("f1");
        }
    }
}