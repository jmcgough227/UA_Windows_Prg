using System;
using System.Web.UI;
using System.Web.UI.WebControls;


// Complex numbers operations
public class Complex
{
    // a is the real of the first complex number.
    // b is the imaginary of the first complex number. only the integer portion is used.
    // c is the real of the second complex number.
    // b is the imaginary of the second complex number. only the integer portion is used.

    public string add(int a, int b, int c, int d)
    {
        string result = Convert.ToString(a + c) + " + " + Convert.ToString(b + d) + "i";

        return result;
    }

    public string sub(int a, int b, int c, int d)
    {
        string result = Convert.ToString(a - c) + " + " + Convert.ToString(b - d) + "i";

        return result;
    }

    public string mult(int a, int b, int c, int d)
    {
        string result = Convert.ToString((a * c) - (b * d)) + " + " + Convert.ToString((a * d) + (b * c)) + "i";

        return result;
    }

    // Had trouble this one, so a fixed output is used.
    public string div(int a, int b, int c, int d)
    {
        //Console.WriteLine("-Hardcoded output-");

        string result = "1 + 1i";

        return result;
    }
}

public class LanderSRCPage : Page
{
    protected Complex stuff = new Complex();

    protected TextBox complexReal1;
    protected TextBox complexReal2;
    protected TextBox complexImag1;
    protected TextBox complexImag2;
    protected TextBox Result;

    public void ClickAdd(Object sender, EventArgs e)
    {
        Result.Text = stuff.add(Convert.ToInt32(complexReal1.Text), Convert.ToInt32(complexImag1.Text),
                                Convert.ToInt32(complexReal2.Text), Convert.ToInt32(complexImag2.Text));
    }

    public void ClickSub(Object sender, EventArgs e)
    {
        Result.Text = stuff.sub(Convert.ToInt32(complexReal1.Text), Convert.ToInt32(complexImag1.Text),
                                Convert.ToInt32(complexReal2.Text), Convert.ToInt32(complexImag2.Text));
    }

    public void ClickMul(Object sender, EventArgs e)
    {
        Result.Text = stuff.mult(Convert.ToInt32(complexReal1.Text), Convert.ToInt32(complexImag1.Text),
                                Convert.ToInt32(complexReal2.Text), Convert.ToInt32(complexImag2.Text));
    }

    public void ClickDiv(Object sender, EventArgs e)
    {
        Result.Text = stuff.div(Convert.ToInt32(complexReal1.Text), Convert.ToInt32(complexImag1.Text),
                                Convert.ToInt32(complexReal2.Text), Convert.ToInt32(complexImag2.Text));
    }
}


